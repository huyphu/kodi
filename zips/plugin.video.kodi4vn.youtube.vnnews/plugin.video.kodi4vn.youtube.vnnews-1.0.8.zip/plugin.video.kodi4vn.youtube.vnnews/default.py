#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc , xbmcaddon , xbmcplugin , xbmcgui , sys , urllib , urllib2 , re , os , base64
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.kodi4vn.youtube.vnnews'
Oo0Ooo = xbmcaddon . Addon ( OO0o )
O0O0OO0O0O0 = int ( sys . argv [ 1 ] )
if 5 - 5: iiI / ii1I
def ooO0OO000o ( ) :
 # ii11i = ""
 # oOooOoO0Oo0O = ( "Busy" , "Bận" , "Band" , "Beschäftigt" , "Bezig" , "忙" , "忙碌" )
 # while True :
  # sys = urllib . quote ( xbmc . getInfoLabel ( "System.KernelVersion" ) . strip ( ) )
  # if not any ( b in sys for b in oOooOoO0Oo0O ) : break
 # while True :
  # iI1 = urllib . quote ( xbmc . getInfoLabel ( "System.FriendlyName" ) . strip ( ) )
  # if not any ( b in iI1 for b in oOooOoO0Oo0O ) : break
 # try :
  # ii11i = open ( '/sys/class/net/eth0/address' ) . read ( ) . strip ( )
 # except :
  # while True :
   # ii11i = xbmc . getInfoLabel ( "Network.MacAddress" ) . strip ( )
   # if re . match ( "[0-9a-f]{2}([-:])[0-9a-f]{2}(\\1[0-9a-f]{2}){4}$" , ii11i . lower ( ) ) : break
 # i1I11i = urllib2 . urlopen ( "http://www.viettv24.com/main/checkActivation.php?MacID=%s&app_id=%s&sys=%s&dev=%s" % ( ii11i , "19" , sys , iI1 ) ) . read ( )
 if True:
  i1I11i = urllib2 . urlopen ( 'https://docs.google.com/spreadsheets/d/1P1ViMaKLDRZzUbHZ5aE192R-juxmMycs2R8RrludeVw/export?format=tsv&id=1P1ViMaKLDRZzUbHZ5aE192R-juxmMycs2R8RrludeVw&gid=0' )
  OoOoOO00 = i1I11i . read ( ) . decode ( 'utf-8-sig' ) . encode ( 'utf8' )
  i1I11i . close ( )
  for I11i in OoOoOO00 . split ( "\n" ) :
   O0O = I11i . split ( "\t" )
   Oo ( O0O [ 0 ] , O0O [ 1 ] , 'index' , '' )
 else :
  # I1ii11iIi11i = xbmcgui . Dialog ( )
  # I1ii11iIi11i . ok ( "Chú ý" , i1I11i )
  I1IiI = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
  I1IiI = xbmc . translatePath ( os . path . join ( I1IiI , "temp.jpg" ) )
 # urllib . urlretrieve ( 'https://googledrive.com/host/0B-ygKtjD8Sc-S04wUUxMMWt5dmM/images/vnnews.jpg' , I1IiI )
 # o0OOO = xbmcgui . ControlImage ( 0 , 0 , 1280 , 720 , I1IiI )
 # iIiiiI = xbmcgui . WindowDialog ( )
 # iIiiiI . addControl ( o0OOO )
 # iIiiiI . doModal ( )
 if 23 - 23: iii1II11ii * i11iII1iiI + iI1Ii11111iIi + ii1II11I1ii1I + oO0o0ooO0 - iiIIIII1i1iI
def o0oO0 ( url ) :
 oo00 = o00 ( url )
 Oo0oO0ooo = re . compile ( "<openSearch:totalResults>(.+?)</openSearch:totalResults><openSearch:startIndex>(.+?)</openSearch:startIndex>" , re . DOTALL ) . findall ( oo00 )
 o0oOoO00o = int ( Oo0oO0ooo [ 0 ] [ 0 ] )
 i1 = int ( Oo0oO0ooo [ 0 ] [ 1 ] )
 oOOoo00O0O = oo00 . split ( '<entry' )
 if i1 < 50 :
  i1111 = re . compile ( "users/(.+?)/" , re . DOTALL ) . findall ( url ) [ 0 ]
  Oo ( "[COLOR orange][B]Hot News[/B][/COLOR]" , "https://gdata.youtube.com/feeds/api/users/%s/uploads?v=2&max-results=50" % i1111 , 'showItems' , '' )
 for i11 in range ( 1 , len ( oOOoo00O0O ) , 1 ) :
  I11 = oOOoo00O0O [ i11 ]
  Oo0oO0ooo = re . compile ( "src='(.+?)'" , re . DOTALL ) . findall ( I11 )
  Oo0o0000o0o0 = Oo0oO0ooo [ 0 ]
  Oo0oO0ooo = re . compile ( "<title>(.+?)</title>" , re . DOTALL ) . findall ( I11 )
  oOo0oooo00o = Oo0oO0ooo [ 0 ]
  if len ( Oo0oO0ooo ) > 0 :
   oOo0oooo00o = Oo0oO0ooo [ 0 ]
   oOo0oooo00o = oO0o0o0ooO0oO ( oOo0oooo00o )
  Oo0oO0ooo = re . compile ( "<media:thumbnail url='(.+?)' height='90' width='120' yt:name='default'/>" , re . DOTALL ) . findall ( I11 )
  oo0o0O00 = ""
  if ( len ( Oo0oO0ooo ) > 0 ) :
   oo0o0O00 = Oo0oO0ooo [ 0 ]
  Oo ( "[B]" + oOo0oooo00o + "[/B]" , Oo0o0000o0o0 , 'showItems' , oo0o0O00 )
 if i1 + 50 <= o0oOoO00o :
  Oo ( "[Next >]" , url + "&start-index=" + str ( int ( i1 ) + 50 ) , "showNextPlaylists" , "" )
  if 68 - 68: o00oo . iI1OoOooOOOO + i11iiII
def Oo ( name , url , mode , iconimage ) :
 I1iiiiI1iII = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 IiIi11i = True
 if iconimage == "" : iconimage = "DefaultFolder.png"
 iIii1I111I11I = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 iIii1I111I11I . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : "" } )
 if ( "youtube.com/user/" in url ) or ( "youtube.com/channel/" in url ) :
  I1iiiiI1iII = "plugin://plugin.video.youtube/%s/%s/" % ( url . split ( "/" ) [ - 2 ] , url . split ( "/" ) [ - 1 ] )
  return xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1iiiiI1iII , listitem = iIii1I111I11I , isFolder = True )
 IiIi11i = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1iiiiI1iII , listitem = iIii1I111I11I , isFolder = True )
 return IiIi11i
 if 72 - 72: OOooO0OOoo % iii11iII / iI111IiI111I + OooOoO0Oo
def iiIIiIiIi ( name , url , mode , iconimage ) :
 I1iiiiI1iII = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 IiIi11i = True
 iIii1I111I11I = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 iIii1I111I11I . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : "" } )
 iIii1I111I11I . setProperty ( 'IsPlayable' , 'true' )
 IiIi11i = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1iiiiI1iII , listitem = iIii1I111I11I )
 return IiIi11i
 if 38 - 38: o0oooO0OO0O / Oooo
def O00o ( youtubeID ) :
 O00 = i11I1 ( youtubeID )
 Ii11Ii11I = xbmcgui . ListItem ( path = O00 )
 Ii11Ii11I . setProperty ( "IsPlayable" , "true" )
 return xbmcplugin . setResolvedUrl ( O0O0OO0O0O0 , True , Ii11Ii11I )
 if 43 - 43: Ii1I11I11i1 - ii11i1iIII - i11iIiiIii
def i11I1 ( youtubeID ) :
 O00 = "plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=" + youtubeID
 return O00
 if 86 - 86: OooOoO0Oo / ii1II11I1ii1I
def Oo0o0 ( ) :
 oo00 = o00 ( O00 + "&max-results=50" )
 Oo0oO0ooo = re . compile ( "<openSearch:totalResults>(.+?)</openSearch:totalResults><openSearch:startIndex>(.+?)</openSearch:startIndex>" , re . DOTALL ) . findall ( oo00 )
 o0oOoO00o = int ( Oo0oO0ooo [ 0 ] [ 0 ] )
 i1 = int ( Oo0oO0ooo [ 0 ] [ 1 ] )
 oOOoo00O0O = oo00 . split ( '<entry' )
 for i11 in range ( 1 , len ( oOOoo00O0O ) , 1 ) :
  I11 = oOOoo00O0O [ i11 ]
  Oo0oO0ooo = re . compile ( "<yt:videoid>(.+?)</yt:videoid>" , re . DOTALL ) . findall ( I11 )
  III1ii1iII = Oo0oO0ooo [ 0 ]
  Oo0oO0ooo = re . compile ( "<title>(.+?)</title>" , re . DOTALL ) . findall ( I11 )
  oOo0oooo00o = Oo0oO0ooo [ 0 ]
  if len ( Oo0oO0ooo ) > 0 :
   oOo0oooo00o = Oo0oO0ooo [ 0 ]
   oOo0oooo00o = oO0o0o0ooO0oO ( oOo0oooo00o )
  Oo0oO0ooo = re . compile ( "<media:thumbnail url='(.+?)' height='90' width='120'" , re . DOTALL ) . findall ( I11 )
  oo0o0O00 = ""
  if len ( Oo0oO0ooo ) > 0 :
   oo0o0O00 = Oo0oO0ooo [ 0 ]
  iiIIiIiIi ( "[B]" + oOo0oooo00o + "[/B]" , III1ii1iII , 'playVideo' , oo0o0O00 )
 if i1 + 50 <= o0oOoO00o :
  Oo ( "[Next >]" , O00 + "&start-index=" + str ( int ( i1 ) + 50 ) + "&max-results=50" , 'showItems' , oo0o0O00 )
  if 54 - 54: ii1II11I1ii1I % iI1Ii11111iIi % iI1Ii11111iIi
def oO0o0o0ooO0oO ( title ) :
 title = title . replace ( "&lt;" , "<" ) . replace ( "&gt;" , ">" ) . replace ( "&amp;" , "&" ) . replace ( "&#039;" , "\\" ) . replace ( "&quot;" , "\"" ) . replace ( "&szlig;" , "ß" ) . replace ( "&ndash;" , "-" )
 title = title . replace ( "&#038;" , "&" ) . replace ( "&#8230;" , "..." ) . replace ( "&#8211;" , "-" ) . replace ( "&#8220;" , "-" ) . replace ( "&#8221;" , "-" ) . replace ( "&#8217;" , "'" )
 title = title . replace ( "&Auml;" , "Ä" ) . replace ( "&Uuml;" , "Ü" ) . replace ( "&Ouml;" , "Ö" ) . replace ( "&auml;" , "ä" ) . replace ( "&uuml;" , "ü" ) . replace ( "&ouml;" , "ö" )
 title = title . strip ( )
 return title
 if 13 - 13: iI1OoOooOOOO . OooOoO0Oo
def o00 ( url ) :
 i11Iiii = urllib2 . Request ( url )
 i11Iiii . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1; rv:19.0) Gecko/20100101 Firefox/19.0' )
 iI = urllib2 . urlopen ( i11Iiii )
 I1i1I1II = iI . read ( )
 iI . close ( )
 return I1i1I1II
 if 45 - 45: Ii1I11I11i1 . o00oo
def oO ( parameters ) :
 ii1i1I1i = { }
 if 53 - 53: Oooo + ii1II11I1ii1I * OOooO0OOoo
 if parameters :
  OooOooooOOoo0 = parameters [ 1 : ] . split ( "&" )
  for o00OO0OOO0 in OooOooooOOoo0 :
   oo0 = o00OO0OOO0 . split ( '=' )
   if ( len ( oo0 ) ) == 2 :
    ii1i1I1i [ oo0 [ 0 ] ] = oo0 [ 1 ]
 return ii1i1I1i
 if 57 - 57: iii11iII . iii11iII
OooOooo = xbmc . translatePath ( Oo0Ooo . getAddonInfo ( 'profile' ) )
if 97 - 97: ii11i1iIII - iii11iII * i11iIiiIii / o00oo % Ii1I11I11i1 - iii1II11ii
if os . path . exists ( OooOooo ) == False :
 os . mkdir ( OooOooo )
OoOo00o = os . path . join ( OooOooo , 'visitor' )
if 70 - 70: o0oooO0OO0O * i11iiII
if os . path . exists ( OoOo00o ) == False :
 from random import randint
 i1II1 = open ( OoOo00o , "w" )
 i1II1 . write ( str ( randint ( 0 , 0x7fffffff ) ) )
 i1II1 . close ( )
 if 66 - 66: iii1II11ii + OooOoO0Oo + OooOoO0Oo - i11iII1iiI
def O0O ( k , e ) :
 O0o0Ooo = [ ]
 e = base64 . urlsafe_b64decode ( e )
 for i11 in range ( len ( e ) ) :
  O00iI1Ii11iII1 = k [ i11 % len ( k ) ]
  Oo0O0O0ooO0O = chr ( ( 256 + ord ( e [ i11 ] ) - ord ( O00iI1Ii11iII1 ) ) % 256 )
  O0o0Ooo . append ( Oo0O0O0ooO0O )
 return "" . join ( O0o0Ooo )
 if 15 - 15: i11iiII + o00oo - iii1II11ii / iii11iII
def oo000OO00Oo ( utm_url ) :
 O0OOO0OOoO0O = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
 import urllib2
 try :
  i11Iiii = urllib2 . Request ( utm_url , None ,
 { 'User-Agent' : O0OOO0OOoO0O }
 )
  iI = urllib2 . urlopen ( i11Iiii ) . read ( )
 except :
  print ( "GA fail: %s" % utm_url )
 return iI
 if 70 - 70: Oooo * oO0o0ooO0 * iI111IiI111I / OooOoO0Oo
def oOOOoO0O00o0 ( group , name ) :
 try :
  try :
   from hashlib import md5
  except :
   from md5 import md5
  from random import randint
  import time
  from urllib import unquote , quote
  from os import environ
  from hashlib import sha1
  iII = "1.0"
  o0 = open ( OoOo00o ) . read ( )
  ooOooo000oOO = "VNNews"
  Oo0oOOo = "UA-52209804-2"
  Oo0OoO00oOO0o = "www.viettv24.com"
  OOO00O = "http://www.google-analytics.com/__utm.gif"
  if name == "None" :
   OOoOO0oo0ooO = OOO00O + "?" + "utmwv=" + iII + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( ooOooo000oOO ) + "&utmac=" + Oo0oOOo + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , o0 , "1" , "1" , "2" ] )
   if 98 - 98: o0oooO0OO0O * o0oooO0OO0O / o0oooO0OO0O + iI111IiI111I
   if 34 - 34: ii11i1iIII
   if 15 - 15: iI111IiI111I * ii11i1iIII * oO0o0ooO0 % i11iIiiIii % o00oo - iii11iII
   if 68 - 68: Ii1I11I11i1 % i11iII1iiI . Oooo . i11iiII
   if 92 - 92: o0oooO0OO0O . Ii1I11I11i1
  else :
   if group == "None" :
    OOoOO0oo0ooO = OOO00O + "?" + "utmwv=" + iII + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( ooOooo000oOO + "/" + name ) + "&utmac=" + Oo0oOOo + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , o0 , "1" , "1" , "2" ] )
    if 31 - 31: Ii1I11I11i1 . o00oo / iiI
    if 89 - 89: o00oo
    if 68 - 68: iiIIIII1i1iI * iii1II11ii % iiI + iiIIIII1i1iI + ii11i1iIII
    if 4 - 4: ii11i1iIII + iiI * iii11iII
    if 55 - 55: oO0o0ooO0 + ii1I / o00oo * OOooO0OOoo - i11iIiiIii - OooOoO0Oo
   else :
    OOoOO0oo0ooO = OOO00O + "?" + "utmwv=" + iII + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( ooOooo000oOO + "/" + group + "/" + name ) + "&utmac=" + Oo0oOOo + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , o0 , "1" , "1" , "2" ] )
    if 25 - 25: i11iiII
    if 7 - 7: i11iII1iiI / ii1II11I1ii1I * Ii1I11I11i1 . Oooo . ii1I
    if 13 - 13: iii11iII / i11iIiiIii
    if 2 - 2: ii1II11I1ii1I / iiI / iI1OoOooOOOO % o00oo % OooOoO0Oo
    if 52 - 52: iI1OoOooOOOO
    if 95 - 95: OooOoO0Oo
  print "============================ POSTING ANALYTICS ============================"
  oo000OO00Oo ( OOoOO0oo0ooO )
  if 87 - 87: ii11i1iIII + o00oo . iii11iII + o00oo
  if not group == "None" :
   oOiIi1IIIi1 = OOO00O + "?" + "utmwv=" + iII + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmhn=" + quote ( Oo0OoO00oOO0o ) + "&utmt=" + "events" + "&utme=" + quote ( "5(" + ooOooo000oOO + "*" + group + "*" + name + ")" ) + "&utmp=" + quote ( ooOooo000oOO ) + "&utmac=" + Oo0oOOo + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , "1" , o0 , "1" , "2" ] )
   if 86 - 86: iI111IiI111I % o00oo / ii1II11I1ii1I / o00oo
   if 42 - 42: iiIIIII1i1iI
   if 67 - 67: Ii1I11I11i1 . o0oooO0OO0O . iiI
   if 10 - 10: i11iiII % i11iiII - ii1I / iii11iII + OooOoO0Oo
   if 87 - 87: OOooO0OOoo * i11iiII + iii11iII / ii1I / o0oooO0OO0O
   if 37 - 37: o0oooO0OO0O - ii11i1iIII * OOooO0OOoo % i11iIiiIii - Ii1I11I11i1
   if 83 - 83: iI111IiI111I / ii1II11I1ii1I
   if 34 - 34: Oooo
   try :
    print "============================ POSTING TRACK EVENT ============================"
    oo000OO00Oo ( oOiIi1IIIi1 )
   except :
    print "============================  CANNOT POST TRACK EVENT ============================"
    if 57 - 57: OOooO0OOoo . iI111IiI111I . i11iII1iiI
 except :
  print "================  CANNOT POST TO ANALYTICS  ================"
  if 42 - 42: iI111IiI111I + i11iiII % iiI
i1iIIIi1i = oO ( sys . argv [ 2 ] )
iI1iIIiiii = i1iIIIi1i . get ( 'mode' )
O00 = i1iIIIi1i . get ( 'url' )
i1iI11i1ii11 = i1iIIIi1i . get ( 'name' )
if type ( O00 ) == type ( str ( ) ) :
 O00 = urllib . unquote_plus ( O00 )
if type ( i1iI11i1ii11 ) == type ( str ( ) ) :
 i1iI11i1ii11 = urllib . unquote_plus ( i1iI11i1ii11 )
if iI1iIIiiii == 'index' :
 oOOOoO0O00o0 ( "Browse" , i1iI11i1ii11 )
 o0oO0 ( O00 )
elif iI1iIIiiii == 'showItems' :
 oOOOoO0O00o0 ( "Browse" , i1iI11i1ii11 )
 Oo0o0 ( )
elif iI1iIIiiii == 'showNextPlaylists' :
 oOOOoO0O00o0 ( "Browse" , i1iI11i1ii11 )
 o0oO0 ( O00 )
elif iI1iIIiiii == 'playVideo' :
 oOOOoO0O00o0 ( "Play" , i1iI11i1ii11 + "/" + O00 )
 OOooo0O00o = xbmcgui . DialogProgress ( )
 OOooo0O00o . create ( 'SBTNOfficial Playlist' , 'Loading video. Please wait...' )
 O00o ( O00 )
 OOooo0O00o . close ( )
 del OOooo0O00o
else :
 oOOOoO0O00o0 ( "None" , "None" )
 ooO0OO000o ( )
xbmcplugin . endOfDirectory ( O0O0OO0O0O0 )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
