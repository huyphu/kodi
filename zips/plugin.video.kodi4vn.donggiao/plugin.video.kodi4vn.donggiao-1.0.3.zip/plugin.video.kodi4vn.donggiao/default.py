#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib , urllib2 , re , zlib , ast , os , uuid
from xbmcswift2 import Plugin , xbmc , xbmcgui , xbmcaddon
oo000 = Plugin ( )
ii = "plugin://plugin.video.kodi4vn.donggiao"
if 51 - 51: IiI1i11I
@ oo000 . route ( '/' )
def Iii1I1 ( ) :
 OOO0O0O0ooooo = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
 OOO0O0O0ooooo = xbmc . translatePath ( os . path . join ( OOO0O0O0ooooo , "temp.jpg" ) )
 # urllib . urlretrieve ( 'https://googledrive.com/host/0B-ygKtjD8Sc-S04wUUxMMWt5dmM/images/donggiao.jpg' , OOO0O0O0ooooo )
 # iIIii1IIi = xbmcgui . ControlImage ( 0 , 0 , 1280 , 720 , OOO0O0O0ooooo )
 # o0OO00 = xbmcgui . WindowDialog ( )
 # o0OO00 . addControl ( iIIii1IIi )
 # o0OO00 . doModal ( )
 oo = ""
 # i1iII1IiiIiI1 = ( "Busy" , "Bận" , "Band" , "Beschäftigt" , "Bezig" , "忙" , "忙碌" )
 # while True :
  # iIiiiI1IiI1I1 = urllib . quote ( xbmc . getInfoLabel ( "System.KernelVersion" ) . strip ( ) )
  # if not any ( b in iIiiiI1IiI1I1 for b in i1iII1IiiIiI1 ) : break
 # while True :
  # o0OoOoOO00 = urllib . quote ( xbmc . getInfoLabel ( "System.FriendlyName" ) . strip ( ) )
  # if not any ( b in o0OoOoOO00 for b in i1iII1IiiIiI1 ) : break
 # try :
  # oo = open ( '/sys/class/net/eth0/address' ) . read ( ) . strip ( )
 # except :
  # while True :
   # oo = xbmc . getInfoLabel ( "Network.MacAddress" ) . strip ( )
   # if re . match ( "[0-9a-f]{2}([-:])[0-9a-f]{2}(\\1[0-9a-f]{2}){4}$" , oo . lower ( ) ) : break
 # I11i = urllib2 . urlopen ( "http://www.viettv24.com/main/checkActivation.php?MacID=%s&app_id=%s&sys=%s&dev=%s" % ( oo , "3" , iIiiiI1IiI1I1 , o0OoOoOO00 ) ) . read ( )
 if True:
  O0O = [
 { 'label' : 'Đồng Giao Official' , 'path' : 'plugin://plugin.video.youtube/channel/UCZTjI84dMcWPLMDd7HjzFnA/' , 'thumbnail' : 'https://yt3.ggpht.com/-5TD-pJoIQRY/AAAAAAAAAAI/AAAAAAAAAAA/oBUSns1u68U/s256-c-k-no/photo.jpg' } ,
 { 'label' : 'Dong Giao Pro' , 'path' : 'plugin://plugin.video.youtube/channel/UCkRLTtpdJj-8Of10-N9E9Ug/' , 'thumbnail' : 'https://yt3.ggpht.com/-S280zJuQrK0/AAAAAAAAAAI/AAAAAAAAAAA/qrXrrcjVT28/s256-c-k-no/photo.jpg' } ,
 { 'label' : 'Giang Nguyen' , 'path' : 'plugin://plugin.video.youtube/channel/UCfxY1HzwvH1gBfAG8O-kNwA/' , 'thumbnail' : 'https://yt3.ggpht.com/-FDJoaZ4E_MU/AAAAAAAAAAI/AAAAAAAAAAA/0F0jKAmhaP0/s256-c-k-no/photo.jpg' } ,
 { 'label' : 'MrBeGiang' , 'path' : 'plugin://plugin.video.youtube/channel/UC1L_0MbpbkPRPE01t8neBZg/' , 'thumbnail' : 'https://yt3.ggpht.com/-WbQ8qe3augw/AAAAAAAAAAI/AAAAAAAAAAA/u3YVPUd0U4o/s256-c-k-no/photo.jpg' }
 ]
  return oo000 . finish ( O0O )
 else :
  Oo = xbmcgui . Dialog ( )
  Oo . ok ( "Chú ý" , I11i )
  if 2 - 2: o0 * i1 * ii1IiI1i % OOooOOo / I11iIi1I / IiiIII111iI
if __name__ == '__main__' :
 oo000 . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
