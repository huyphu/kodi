#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib , urllib2 , re , zlib , os , uuid , ast
from xbmcswift2 import Plugin , xbmc , xbmcgui , xbmcaddon
oo000 = Plugin ( )
ii = "plugin://plugin.video.kodi4vn.phimvang.org"
oOOo = 48
if 59 - 59: Oo0Ooo . OO0OO0O0O0 * iiiIIii1IIi . iII111iiiii11 % I1IiiI
@ oo000 . route ( '/' )
def IIi1IiiiI1Ii ( ) :
 I11i11Ii ( "None" , "None" )
 # oO00oOo = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
 # oO00oOo = xbmc . translatePath ( os . path . join ( oO00oOo , "temp.jpg" ) )
 # urllib . urlretrieve ( 'https://googledrive.com/host/0B-ygKtjD8Sc-S04wUUxMMWt5dmM/images/phimvang.jpg' , oO00oOo )
 # OOOo0 = xbmcgui . ControlImage ( 0 , 0 , 1280 , 720 , oO00oOo )
 # Oooo000o = xbmcgui . WindowDialog ( )
 # Oooo000o . addControl ( OOOo0 )
 # Oooo000o . doModal ( )
 # IiIi11iIIi1Ii = ""
 # Oo0O = ( "Busy" , "Bận" , "Band" , "Beschäftigt" , "Bezig" , "忙" , "忙碌" )
 # while True :
  # IiI = urllib . quote ( xbmc . getInfoLabel ( "System.KernelVersion" ) . strip ( ) )
  # if not any ( b in IiI for b in Oo0O ) : break
 # while True :
  # ooOo = urllib . quote ( xbmc . getInfoLabel ( "System.FriendlyName" ) . strip ( ) )
  # if not any ( b in ooOo for b in Oo0O ) : break
 # try :
  # IiIi11iIIi1Ii = open ( '/sys/class/net/eth0/address' ) . read ( ) . strip ( )
 # except :
  # while True :
   # IiIi11iIIi1Ii = xbmc . getInfoLabel ( "Network.MacAddress" ) . strip ( )
   # if re . match ( "[0-9a-f]{2}([-:])[0-9a-f]{2}(\\1[0-9a-f]{2}){4}$" , IiIi11iIIi1Ii . lower ( ) ) : break
 # Oo = urllib2 . urlopen ( "http://www.viettv24.com/main/checkActivation.php?MacID=%s&app_id=%s&sys=%s&dev=%s" % ( IiIi11iIIi1Ii , "13" , IiI , ooOo ) ) . read ( )
 if True:
  o0O = [
 { 'label' : 'Phim mới' , 'path' : '%s/latest/%s/%s' % ( ii , urllib . quote_plus ( 'http://phim7.com/phim-moi/trang-%s.html' ) , 1 ) } ,
 { 'label' : 'Phim HOT' , 'path' : '%s/hot/%s/%s' % ( ii , urllib . quote_plus ( 'http://phim7.com/phim-hot/trang-%s.html' ) , 1 ) } ,
 { 'label' : 'Phim xem nhiều' , 'path' : '%s/most_view/%s/%s' % ( ii , urllib . quote_plus ( 'http://phim7.com/phim-xem-nhieu/trang-%s.html' ) , 1 ) } ,
 { 'label' : 'Phim chiếu rạp' , 'path' : '%s/cine/%s/%s' % ( ii , urllib . quote_plus ( 'http://phim7.com/phim-chieu-rap/trang-%s.html' ) , 1 ) } ,
 { 'label' : 'Phim bộ' , 'path' : '%s/series/%s/%s' % ( ii , urllib . quote_plus ( 'http://phim7.com/phim-bo/trang-%s.html' ) , 1 ) } ,
 { 'label' : 'Phim lẻ' , 'path' : '%s/movies/%s/%s' % ( ii , urllib . quote_plus ( 'http://phim7.com/phim-le/trang-%s.html' ) , 1 ) } ,
 { 'label' : 'Thể loại' , 'path' : '%s/genres' % ii } ,
 { 'label' : 'Quốc gia' , 'path' : '%s/nations' % ii } ,
 { 'label' : 'Tìm kiếm' , 'path' : '%s/search' % ii }
 ]
  return oo000 . finish ( o0O )
 else :
  IiiIII111iI = xbmcgui . Dialog ( )
  IiiIII111iI . ok ( "Chú ý" , Oo )
  if 34 - 34: iii1I1I / O00oOoOoO0o0O . O0oo0OO0 + Oo0ooO0oo0oO . I1i1iI1i - II
  if 100 - 100: i11Ii11I1Ii1i . ooO - OOoO / ooo0Oo0 * i1 - OOooo0000ooo
@ oo000 . route ( '/latest/<murl>/<page>' )
def OOo000 ( murl , page ) :
 I11i11Ii ( "Browse" , '/latest/%s/%s' % ( murl , page ) )
 o0O = O0 ( murl , page , 'latest' )
 if xbmc . getSkinDir ( ) == 'skin.xeebo' and oo000 . get_setting ( 'thumbview' , bool ) :
  return oo000 . finish ( o0O , view_mode = 52 )
 else :
  return oo000 . finish ( o0O )
  if 34 - 34: O0o00 % o0ooo / OOO0O / iiiIIii1IIi * iII111iiiii11 * OOO0O
@ oo000 . route ( '/hot/<murl>/<page>' )
def i1iIIII ( murl , page ) :
 I11i11Ii ( "Browse" , '/hot/%s/%s' % ( murl , page ) )
 o0O = O0 ( murl , page , 'hot' )
 if xbmc . getSkinDir ( ) == 'skin.xeebo' and oo000 . get_setting ( 'thumbview' , bool ) :
  return oo000 . finish ( o0O , view_mode = 52 )
 else :
  return oo000 . finish ( o0O )
  if 26 - 26: o0ooo . ooo0Oo0 - OOoO % OO0OO0O0O0 + OOoO
@ oo000 . route ( '/most_view/<murl>/<page>' )
def i1iiIIiiI111 ( murl , page ) :
 I11i11Ii ( "Browse" , '/most_view/%s/%s' % ( murl , page ) )
 o0O = O0 ( murl , page , 'most_view' )
 if xbmc . getSkinDir ( ) == 'skin.xeebo' and oo000 . get_setting ( 'thumbview' , bool ) :
  return oo000 . finish ( o0O , view_mode = 52 )
 else :
  return oo000 . finish ( o0O )
  if 62 - 62: Oo0Ooo - iii1I1I
@ oo000 . route ( '/cine/<murl>/<page>' )
def IIIiI11ii ( murl , page ) :
 I11i11Ii ( "Browse" , '/cine/%s/%s' % ( murl , page ) )
 o0O = O0 ( murl , page , 'cine' )
 if xbmc . getSkinDir ( ) == 'skin.xeebo' and oo000 . get_setting ( 'thumbview' , bool ) :
  return oo000 . finish ( o0O , view_mode = 52 )
 else :
  return oo000 . finish ( o0O )
  if 52 - 52: OOooo0000ooo + OOoO % iII111iiiii11 / Oo0Ooo
@ oo000 . route ( '/movies/<murl>/<page>' )
def iiIIi1IiIi11 ( murl , page ) :
 I11i11Ii ( "Browse" , '/movies/%s/%s' % ( murl , page ) )
 o0O = O0 ( murl , page , 'movies' )
 if xbmc . getSkinDir ( ) == 'skin.xeebo' and oo000 . get_setting ( 'thumbview' , bool ) :
  return oo000 . finish ( o0O , view_mode = 52 )
 else :
  return oo000 . finish ( o0O )
  if 11 - 11: OOO0O / OO0OO0O0O0 - I1IiiI
@ oo000 . route ( '/series/<murl>/<page>' )
def o00O00O0O0O ( murl , page ) :
 I11i11Ii ( "Browse" , '/series/%s/%s' % ( murl , page ) )
 o0O = O0 ( murl , page , 'series' )
 if xbmc . getSkinDir ( ) == 'skin.xeebo' and oo000 . get_setting ( 'thumbview' , bool ) :
  return oo000 . finish ( o0O , view_mode = 52 )
 else :
  return oo000 . finish ( o0O )
  if 90 - 90: iii1I1I + ooO / II % iii1I1I - OO0OO0O0O0
@ oo000 . route ( '/genres' )
def iIii1 ( ) :
 I11i11Ii ( "Browse" , '/genres' )
 o0O = [
 { 'label' : 'Clip Vui' , 'path' : '%s/genres/%s/%s' % ( ii , urllib . quote_plus ( 'http://phim7.com/the-loai/clip-vui/trang-%s.html' ) , 1 ) } ,
 { 'label' : 'Hành Động' , 'path' : '%s/genres/%s/%s' % ( ii , urllib . quote_plus ( 'http://phim7.com/the-loai/hanh-dong-xa-hoi-den/trang-%s.html' ) , 1 ) } ,
 { 'label' : 'Võ Thuật - Kiếm Hiệp' , 'path' : '%s/genres/%s/%s' % ( ii , urllib . quote_plus ( 'http://phim7.com/the-loai/vo-thuat-kiem-hiep/trang-%s.html' ) , 1 ) } ,
 { 'label' : 'Tâm Lý - Tình Cảm' , 'path' : '%s/genres/%s/%s' % ( ii , urllib . quote_plus ( 'http://phim7.com/the-loai/tam-ly-tinh-cam/trang-%s.html' ) , 1 ) } ,
 { 'label' : 'Hài Hước' , 'path' : '%s/genres/%s/%s' % ( ii , urllib . quote_plus ( 'http://phim7.com/the-loai/hai-huoc/trang-%s.html' ) , 1 ) } ,
 { 'label' : 'Kinh Dị - Ma' , 'path' : '%s/genres/%s/%s' % ( ii , urllib . quote_plus ( 'http://phim7.com/the-loai/kinh-di-ma/trang-%s.html' ) , 1 ) } ,
 { 'label' : 'Phiêu Lưu' , 'path' : '%s/genres/%s/%s' % ( ii , urllib . quote_plus ( 'http://phim7.com/the-loai/phieu-luu/trang-%s.html' ) , 1 ) } ,
 { 'label' : 'Thần Thoại' , 'path' : '%s/genres/%s/%s' % ( ii , urllib . quote_plus ( 'http://phim7.com/the-loai/than-thoai/trang-%s.html' ) , 1 ) } ,
 { 'label' : 'Viễn Tưởng' , 'path' : '%s/genres/%s/%s' % ( ii , urllib . quote_plus ( 'http://phim7.com/the-loai/vien-tuong/trang-%s.html' ) , 1 ) } ,
 { 'label' : 'Hoạt Hình' , 'path' : '%s/genres/%s/%s' % ( ii , urllib . quote_plus ( 'http://phim7.com/the-loai/hoat-hinh/trang-%s.html' ) , 1 ) } ,
 { 'label' : 'Chiến Tranh' , 'path' : '%s/genres/%s/%s' % ( ii , urllib . quote_plus ( 'http://phim7.com/the-loai/chien-tranh/trang-%s.html' ) , 1 ) } ,
 { 'label' : 'Thể Thao - Âm Nhạc' , 'path' : '%s/genres/%s/%s' % ( ii , urllib . quote_plus ( 'http://phim7.com/the-loai/the-thao-am-nhac/trang-%s.html' ) , 1 ) } ,
 { 'label' : 'Phim Việt Nam' , 'path' : '%s/genres/%s/%s' % ( ii , urllib . quote_plus ( 'http://phim7.com/the-loai/phim-viet-nam/trang-%s.html' ) , 1 ) } ,
 { 'label' : 'Phim Bộ Trung Quốc' , 'path' : '%s/genres/%s/%s' % ( ii , urllib . quote_plus ( 'http://phim7.com/the-loai/phim-bo-trung-quoc/trang-%s.html' ) , 1 ) } ,
 { 'label' : 'Phim Bộ Đài Loan' , 'path' : '%s/genres/%s/%s' % ( ii , urllib . quote_plus ( 'http://phim7.com/the-loai/phim-bo-dai-loan/trang-%s.html' ) , 1 ) } ,
 { 'label' : 'Phim Bộ Hàn Quốc' , 'path' : '%s/genres/%s/%s' % ( ii , urllib . quote_plus ( 'http://phim7.com/the-loai/phim-bo-han-quoc/trang-%s.html' ) , 1 ) } ,
 { 'label' : 'Music Box' , 'path' : '%s/genres/%s/%s' % ( ii , urllib . quote_plus ( 'http://phim7.com/the-loai/music-box/trang-%s.html' ) , 1 ) }
 ]
 return oo000 . finish ( o0O )
 if 71 - 71: Oo0ooO0oo0oO
@ oo000 . route ( '/genres/<murl>/<page>' )
def oO0O ( murl , page = 1 ) :
 I11i11Ii ( "Browse" , '/genres/%s/%s' % ( murl , page ) )
 o0O = O0 ( murl , page , 'genres' )
 if xbmc . getSkinDir ( ) == 'skin.xeebo' and oo000 . get_setting ( 'thumbview' , bool ) :
  return oo000 . finish ( o0O , view_mode = 52 )
 else :
  return oo000 . finish ( o0O )
  if 70 - 70: O0oo0OO0 % O0oo0OO0 . O0o00 % Oo0ooO0oo0oO * II % ooO
@ oo000 . route ( '/nations' )
def iiI1IiI ( ) :
 I11i11Ii ( "Browse" , '/nations' )
 o0O = [
 { 'label' : 'Việt Nam' , 'path' : '%s/nations/%s/%s' % ( ii , urllib . quote_plus ( 'http://phim7.com/quoc-gia/viet-nam/trang-%s.html' ) , 1 ) } ,
 { 'label' : 'Trung Quốc' , 'path' : '%s/nations/%s/%s' % ( ii , urllib . quote_plus ( 'http://phim7.com/quoc-gia/trung-quoc/trang-%s.html' ) , 1 ) } ,
 { 'label' : 'Hàn Quốc' , 'path' : '%s/nations/%s/%s' % ( ii , urllib . quote_plus ( 'http://phim7.com/quoc-gia/han-quoc/trang-%s.html' ) , 1 ) } ,
 { 'label' : 'Nhật Bản' , 'path' : '%s/nations/%s/%s' % ( ii , urllib . quote_plus ( 'http://phim7.com/quoc-gia/nhat-ban/trang-%s.html' ) , 1 ) } ,
 { 'label' : 'Mỹ - Châu Âu' , 'path' : '%s/nations/%s/%s' % ( ii , urllib . quote_plus ( 'http://phim7.com/quoc-gia/my-chau-au/trang-%s.html' ) , 1 ) } ,
 { 'label' : 'Thái Lan' , 'path' : '%s/nations/%s/%s' % ( ii , urllib . quote_plus ( 'http://phim7.com/quoc-gia/thai-lan/trang-%s.html' ) , 1 ) } ,
 { 'label' : 'Châu Á' , 'path' : '%s/nations/%s/%s' % ( ii , urllib . quote_plus ( 'http://phim7.com/quoc-gia/chau-a/trang-%s.html' ) , 1 ) } ,
 { 'label' : 'Ấn Độ' , 'path' : '%s/nations/%s/%s' % ( ii , urllib . quote_plus ( 'http://phim7.com/quoc-gia/an-do/trang-%s.html' ) , 1 ) }
 ]
 return oo000 . finish ( o0O )
 if 13 - 13: O0oo0OO0 . Oo0Ooo - iiiIIii1IIi - I1i1iI1i
@ oo000 . route ( '/nations/<murl>/<page>' )
def ii1I ( murl , page ) :
 I11i11Ii ( "Browse" , '/nations/%s/%s' % ( murl , page ) )
 o0O = O0 ( murl , page , 'nations' )
 if xbmc . getSkinDir ( ) == 'skin.xeebo' and oo000 . get_setting ( 'thumbview' , bool ) :
  return oo000 . finish ( o0O , view_mode = 52 )
 else :
  return oo000 . finish ( o0O )
  if 76 - 76: OO0OO0O0O0 / II . O00oOoOoO0o0O * i1 - OOoO
@ oo000 . route ( '/search/' )
def Oooo ( ) :
 I11i11Ii ( "Browse" , '/search' )
 O00o = oo000 . keyboard ( heading = 'Tìm kiếm' )
 if O00o :
  O00 = "http://phim7.com/tim-kiem/tat-ca/keyword/trang-%s.html" . replace ( "keyword" , O00o ) . replace ( " " , "-" )
  i11I1 = '%s/search/%s/%s' % ( ii , urllib . quote_plus ( O00 ) , 1 )
  oo000 . redirect ( i11I1 )
  if 8 - 8: iiiIIii1IIi - O0o00 % iiiIIii1IIi - i1 * O00oOoOoO0o0O
@ oo000 . route ( '/search/<murl>/<page>' )
def iI11i1I1 ( murl , page ) :
 I11i11Ii ( "Browse" , '/search/%s/%s' % ( murl , page ) )
 o0O = O0 ( murl , page , 'search' )
 if xbmc . getSkinDir ( ) == 'skin.xeebo' and oo000 . get_setting ( 'thumbview' , bool ) :
  return oo000 . finish ( o0O , view_mode = 52 )
 else :
  return oo000 . finish ( o0O )
  if 71 - 71: OOO0O % OOooo0000ooo / II
@ oo000 . route ( '/mirrors/<murl>' )
def ii11i1iIII ( murl ) :
 I11i11Ii ( "Browse" , '/mirrors/%s' % ( murl ) )
 o0O = [ ]
 for Ii1I in Oo0o0 ( murl ) :
  III1ii1iII = { }
  III1ii1iII [ "label" ] = Ii1I [ "name" ] . strip ( )
  oo0oooooO0 = str ( uuid . uuid1 ( ) )
  i11Iiii = oo000 . get_storage ( oo0oooooO0 )
  i11Iiii [ "list" ] = Ii1I [ "eps" ]
  III1ii1iII [ "path" ] = '%s/eps/%s' % ( ii , urllib . quote_plus ( oo0oooooO0 ) )
  o0O . append ( III1ii1iII )
 return oo000 . finish ( o0O )
 if 23 - 23: II . iii1I1I
@ oo000 . route ( '/eps/<eps_list>' )
def Oo0O0OOOoo ( eps_list ) :
 I11i11Ii ( "Browse" , '/eps' )
 o0O = [ ]
 for oOoOooOo0o0 in oo000 . get_storage ( eps_list ) [ "list" ] :
  III1ii1iII = { }
  III1ii1iII [ "label" ] = oOoOooOo0o0 [ "name" ] . strip ( )
  III1ii1iII [ "is_playable" ] = True
  III1ii1iII [ "path" ] = '%s/play/%s' % ( ii , urllib . quote_plus ( oOoOooOo0o0 [ "url" ] ) )
  o0O . append ( III1ii1iII )
 return oo000 . finish ( o0O )
 if 61 - 61: II / Oo0ooO0oo0oO + OOO0O * ooO / ooO
@ oo000 . route ( '/play/<url>' )
def OoOo ( url ) :
 I11i11Ii ( "Play" , '/play/%s' % ( url ) )
 iI = xbmcgui . DialogProgress ( )
 iI . create ( 'phim7.com' , 'Loading video. Please wait...' )
 oo000 . set_resolved_url ( o00O ( url ) )
 iI . close ( )
 del iI
 if 69 - 69: ooO % o0ooo - II + o0ooo - OO0OO0O0O0 % iII111iiiii11
def o00O ( url ) :
 Oo = Iii111II ( url )
 iiii11I = ""
 if "youtube" in Oo :
  Ooo0OO0oOO = re . compile ( '(youtu\.be\/|youtube-nocookie\.com\/|youtube\.com\/(watch\?(.*&)?v=|(embed|v|user)\/))([^\?&"\'>]+)' ) . findall ( Oo )
  ii11i1 = Ooo0OO0oOO [ 0 ] [ len ( Ooo0OO0oOO [ 0 ] ) - 1 ] . replace ( 'v/' , '' )
  return 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % ii11i1
 if "lh3.googleusercontent.com" in Oo :
  IIIii1II1II = re . compile ( '"(https://lh3.googleusercontent.com/.+?)"' ) . findall ( Oo )
  iiii11I = IIIii1II1II [ 0 ]
  if oo000 . get_setting ( 'HQ' , bool ) and ( len ( IIIii1II1II ) > 1 ) :
   iiii11I = IIIii1II1II [ 1 ]
  return iiii11I
 if "redirector.googlevideo.com/videoplayback" in Oo :
  IIIii1II1II = re . compile ( '"(https://redirector.googlevideo.com/.+?)"' ) . findall ( Oo )
  iiii11I = IIIii1II1II [ 0 ]
  if oo000 . get_setting ( 'HQ' , bool ) and ( len ( IIIii1II1II ) > 1 ) :
   iiii11I = IIIii1II1II [ 1 ]
  return iiii11I
  if 42 - 42: i1 + ooO
def O0 ( url , page , route_name ) :
 o0O0o0Oo = int ( page ) + 1
 Oo = Iii111II ( url % page )
 Ooo0OO0oOO = re . compile ( '<h2><a href="(.+?)" title="(.+?)">.+?<img class="lazy"[^>]*data-original="(.+?)"[^>]*/>' ) . findall ( Oo )
 o0O = [ ]
 for Ii11Ii1I , O00oO , I11i1I1I in Ooo0OO0oOO :
  III1ii1iII = { }
  III1ii1iII [ "label" ] = O00oO
  III1ii1iII [ "thumbnail" ] = I11i1I1I
  III1ii1iII [ "path" ] = '%s/%s/%s' % ( ii , "mirrors" , urllib . quote_plus ( "http://phim7.com" + Ii11Ii1I . replace ( "/phim/" , "/xem-phim/" ) ) )
  o0O . append ( III1ii1iII )
 if len ( o0O ) == oOOo :
  o0O . append ( { 'label' : 'Next >>' , 'path' : '%s/%s/%s/%s' % ( ii , route_name , urllib . quote_plus ( url ) , o0O0o0Oo ) , 'thumbnail' : 'http://icons.iconarchive.com/icons/rafiqul-hassan/blogger/128/Arrow-Next-icon.png' } )
 return o0O
 if 83 - 83: i11Ii11I1Ii1i / OOO0O
def Oo0o0 ( murl ) :
 Oo = Iii111II ( murl )
 Ooo0OO0oOO = re . compile ( '<p class="epi"><b>(.+?)</b>(.+?)</p>' ) . findall ( Oo )
 iIIIIii1 = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo ) [ 0 ]
 oo000OO00Oo = [ ]
 for O0OOO0OOoO0O , O00Oo000ooO0 in Ooo0OO0oOO :
  OoO0O00 = [ ]
  for IIiII , o0 in re . compile ( '<a href="(.+?)"[^>]*>(.+?)</a>' ) . findall ( O00Oo000ooO0 ) :
   oOoOooOo0o0 = { }
   oOoOooOo0o0 [ "url" ] = "http://phim7.com" + IIiII
   oOoOooOo0o0 [ "name" ] = "Part %s - %s" % ( o0 , iIIIIii1 )
   OoO0O00 . append ( oOoOooOo0o0 )
  if "Xem Full" in OoO0O00 [ 0 ] [ "name" ] : del OoO0O00 [ 0 ]
  Ii1I = { }
  Ii1I [ "name" ] = O0OOO0OOoO0O
  Ii1I [ "eps" ] = OoO0O00
  oo000OO00Oo . append ( Ii1I )
 return oo000OO00Oo
 if 62 - 62: iiiIIii1IIi * I1i1iI1i
@ oo000 . cached ( TTL = 60 )
def Iii111II ( url ) :
 i1OOO = urllib2 . Request ( url )
 i1OOO . add_header ( 'Accept' , 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8' )
 i1OOO . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.65 Safari/537.36' )
 i1OOO . add_header ( 'Accept-Encoding' , 'gzip, deflate, sdch' )
 Oo0oOOo = urllib2 . urlopen ( i1OOO )
 Oo0OoO00oOO0o = Oo0oOOo . read ( )
 Oo0oOOo . close ( )
 if "gzip" in Oo0oOOo . info ( ) . getheader ( 'Content-Encoding' ) :
  Oo0OoO00oOO0o = zlib . decompress ( Oo0OoO00oOO0o , 16 + zlib . MAX_WBITS )
 Oo0OoO00oOO0o = '' . join ( Oo0OoO00oOO0o . splitlines ( ) ) . replace ( '\'' , '"' )
 Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '\n' , '' )
 Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '\t' , '' )
 Oo0OoO00oOO0o = re . sub ( '  +' , ' ' , Oo0OoO00oOO0o )
 Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '> <' , '><' )
 return Oo0OoO00oOO0o
 if 80 - 80: ooO + OOoO - OOoO % OOooo0000ooo
OoOO0oo0o = xbmc . translatePath ( xbmcaddon . Addon ( 'plugin.video.kodi4vn.phimvang.org' ) . getAddonInfo ( 'profile' ) )
if 14 - 14: II * OOooo0000ooo * OOooo0000ooo / I1i1iI1i
if os . path . exists ( OoOO0oo0o ) == False :
 os . mkdir ( OoOO0oo0o )
Oo0o00 = os . path . join ( OoOO0oo0o , 'visitor' )
if 73 - 73: OOooo0000ooo * i1 + II . OOoO + i11Ii11I1Ii1i % OOooo0000ooo
if os . path . exists ( Oo0o00 ) == False :
 from random import randint
 oo0O = open ( Oo0o00 , "w" )
 oo0O . write ( str ( randint ( 0 , 0x7fffffff ) ) )
 oo0O . close ( )
 if 92 - 92: OOooo0000ooo . o0ooo
def i1i ( utm_url ) :
 iiI111I1iIiI = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
 import urllib2
 try :
  i1OOO = urllib2 . Request ( utm_url , None ,
 { 'User-Agent' : iiI111I1iIiI }
 )
  Oo0oOOo = urllib2 . urlopen ( i1OOO ) . read ( )
 except :
  print ( "GA fail: %s" % utm_url )
 return Oo0oOOo
 if 41 - 41: O0oo0OO0 . OOO0O + OO0OO0O0O0 * II % O0oo0OO0 * O0oo0OO0
def I11i11Ii ( group , name ) :
 try :
  try :
   from hashlib import md5
  except :
   from md5 import md5
  from random import randint
  import time
  from urllib import unquote , quote
  from os import environ
  from hashlib import sha1
  iIIIIi1iiIi1 = "1.0"
  iii1i1iiiiIi = open ( Oo0o00 ) . read ( )
  Iiii = "PhimVang.org"
  OO0OoO0o00 = "UA-52209804-2"
  ooOO0O0ooOooO = "www.viettv24.com"
  oOOOo00O00oOo = "http://www.google-analytics.com/__utm.gif"
  if name == "None" :
   iiIIIi = oOOOo00O00oOo + "?" + "utmwv=" + iIIIIi1iiIi1 + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( Iiii ) + "&utmac=" + OO0OoO0o00 + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , iii1i1iiiiIi , "1" , "1" , "2" ] )
   if 93 - 93: OOooo0000ooo
   if 10 - 10: ooo0Oo0
   if 82 - 82: i11Ii11I1Ii1i - iiiIIii1IIi / OOoO + i1
   if 87 - 87: ooO * i11Ii11I1Ii1i + OOoO / iiiIIii1IIi / OOooo0000ooo
   if 37 - 37: OOooo0000ooo - OOO0O * ooO % Oo0Ooo - o0ooo
  else :
   if group == "None" :
    iiIIIi = oOOOo00O00oOo + "?" + "utmwv=" + iIIIIi1iiIi1 + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( Iiii + "/" + name ) + "&utmac=" + OO0OoO0o00 + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , iii1i1iiiiIi , "1" , "1" , "2" ] )
    if 83 - 83: ooo0Oo0 / O00oOoOoO0o0O
    if 34 - 34: O0o00
    if 57 - 57: ooO . ooo0Oo0 . I1IiiI
    if 42 - 42: ooo0Oo0 + i11Ii11I1Ii1i % OO0OO0O0O0
    if 6 - 6: ooO
   else :
    iiIIIi = oOOOo00O00oOo + "?" + "utmwv=" + iIIIIi1iiIi1 + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( Iiii + "/" + group + "/" + name ) + "&utmac=" + OO0OoO0o00 + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , iii1i1iiiiIi , "1" , "1" , "2" ] )
    if 68 - 68: I1i1iI1i - Oo0ooO0oo0oO
    if 28 - 28: Oo0ooO0oo0oO . OOoO / OOoO + O0oo0OO0 . i11Ii11I1Ii1i
    if 1 - 1: iiiIIii1IIi / iii1I1I
    if 33 - 33: ooo0Oo0
    if 18 - 18: II % OOooo0000ooo * OO0OO0O0O0
    if 87 - 87: Oo0Ooo
  print "============================ POSTING ANALYTICS ============================"
  i1i ( iiIIIi )
  if 93 - 93: i11Ii11I1Ii1i - Oo0ooO0oo0oO % Oo0Ooo . OOooo0000ooo / OOooo0000ooo - o0ooo
  if not group == "None" :
   IIII = oOOOo00O00oOo + "?" + "utmwv=" + iIIIIi1iiIi1 + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmhn=" + quote ( ooOO0O0ooOooO ) + "&utmt=" + "events" + "&utme=" + quote ( "5(" + Iiii + "*" + group + "*" + name + ")" ) + "&utmp=" + quote ( Iiii ) + "&utmac=" + OO0OoO0o00 + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , "1" , iii1i1iiiiIi , "1" , "2" ] )
   if 32 - 32: iII111iiiii11 / iiiIIii1IIi - II
   if 91 - 91: OOooo0000ooo % I1IiiI % iiiIIii1IIi
   if 20 - 20: OOoO % i1 / i1 + i1
   if 45 - 45: ooO - O0o00 - iII111iiiii11 - Oo0ooO0oo0oO . iii1I1I / OO0OO0O0O0
   if 51 - 51: OO0OO0O0O0 + OOooo0000ooo
   if 8 - 8: ooO * I1i1iI1i - i1 - Oo0ooO0oo0oO * OOoO % O00oOoOoO0o0O
   if 48 - 48: OO0OO0O0O0
   if 11 - 11: ooo0Oo0 + iII111iiiii11 - Oo0ooO0oo0oO / II + O0oo0OO0 . iii1I1I
   try :
    print "============================ POSTING TRACK EVENT ============================"
    i1i ( IIII )
   except :
    print "============================  CANNOT POST TRACK EVENT ============================"
    if 41 - 41: i1 - OO0OO0O0O0 - OO0OO0O0O0
 except :
  print "================  CANNOT POST TO ANALYTICS  ================"
  if 68 - 68: OOoO % o0ooo
if __name__ == '__main__' :
 oo000 . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
